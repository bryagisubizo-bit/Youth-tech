/* Common Ground Field Notes style: editorial civic design, oat paper surfaces, ink typography, moss steadiness, marigold signal tabs, asymmetrical resource-guide layout. */
import { useMemo, useState } from "react";
import { Link } from "wouter";
import { ArrowUpRight, BookOpen, ChevronRight, Clock3, HeartHandshake, MapPin, Menu, Search, Sparkles, X } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { toast } from "sonner";

const categories = [
  { label: "Everyday essentials", detail: "Food, housing, money, and practical support", icon: HeartHandshake, color: "bg-[#E8EFE7]" },
  { label: "Health & wellbeing", detail: "Care, connection, and a steadier next step", icon: Sparkles, color: "bg-[#F4E8D9]" },
  { label: "Learning & work", detail: "Skills, training, jobs, and new possibilities", icon: BookOpen, color: "bg-[#E6E8F0]" },
  { label: "Your neighbourhood", detail: "Local places, groups, events, and ways to help", icon: MapPin, color: "bg-[#F0E5DF]" },
];

const resources = [
  { category: "Start here", title: "A simple guide to finding local support", description: "A calm way to work out what kind of help might fit your situation, without needing to know the right words first.", image: "/manus-storage/common-ground-resource-hands_b11f7302.jpg", time: "4 min read", tag: "Guide" },
  { category: "Neighbourhoods", title: "Small places that make a real difference", description: "Libraries, gardens, kitchens, and community rooms can be useful long before they feel familiar.", image: "/manus-storage/common-ground-resource-garden_0310a775.jpg", time: "6 min read", tag: "Places" },
  { category: "Learning & work", title: "Keep your next move practical", description: "A short list of places to learn something new, ask a question, or meet someone who has been there.", image: "/manus-storage/common-ground-resource-library_fc51f834.jpg", time: "5 min read", tag: "Ideas" },
];

export default function Home() {
  const [query, setQuery] = useState("");
  const [menuOpen, setMenuOpen] = useState(false);
  const filtered = useMemo(() => resources.filter((item) => `${item.title} ${item.description} ${item.category}`.toLowerCase().includes(query.toLowerCase())), [query]);
  const comingSoon = () => toast("This part of Common Ground is coming next.", { description: "Tell us what would make it most useful for you." });

  return (
    <div className="min-h-screen overflow-hidden bg-[#F6F1E8] text-[#1F2923]">
      <a href="#main" className="skip-link">Skip to content</a>
      <header className="relative z-20 border-b border-[#1F2923]/10 bg-[#F6F1E8]/90 backdrop-blur-md">
        <div className="mx-auto flex max-w-[1320px] items-center justify-between px-5 py-5 lg:px-10">
          <Link href="/" className="group flex items-center gap-3" aria-label="Common Ground home">
            <span className="grid size-10 place-items-center rounded-full bg-[#E5A83B] shadow-[3px_3px_0_#1F2923] transition-transform duration-200 group-hover:rotate-6 group-active:scale-95">
              <img src="/manus-storage/common-ground-loop-mark_6d1b3c89.png" alt="" className="size-7 object-contain" />
            </span>
            <span className="font-display text-xl font-bold tracking-[-0.04em]">Common Ground<span className="text-[#B65E43]">.</span></span>
          </Link>
          <nav className="hidden items-center gap-8 text-sm font-semibold md:flex" aria-label="Primary navigation">
            <a href="#find-help" className="nav-link">Find support</a>
            <a href="#resources" className="nav-link">Browse resources</a>
            <button onClick={comingSoon} className="nav-link">About the guide</button>
          </nav>
          <div className="flex items-center gap-3">
            <button onClick={comingSoon} className="hidden text-sm font-bold text-[#355A45] underline-offset-4 hover:underline sm:block">Suggest a resource</button>
            <button className="grid size-10 place-items-center rounded-full border border-[#1F2923]/20 md:hidden" onClick={() => setMenuOpen(!menuOpen)} aria-label={menuOpen ? "Close menu" : "Open menu"}>{menuOpen ? <X size={19} /> : <Menu size={19} />}</button>
          </div>
        </div>
        {menuOpen && <nav className="border-t border-[#1F2923]/10 px-5 py-5 md:hidden" aria-label="Mobile navigation"><div className="flex flex-col gap-4 text-base font-semibold"><a href="#find-help" onClick={() => setMenuOpen(false)}>Find support</a><a href="#resources" onClick={() => setMenuOpen(false)}>Browse resources</a><button className="text-left" onClick={comingSoon}>About the guide</button></div></nav>}
      </header>

      <main id="main">
        <section className="relative mx-auto grid max-w-[1320px] gap-10 px-5 pb-20 pt-14 lg:grid-cols-[1.05fr_0.95fr] lg:gap-20 lg:px-10 lg:pb-28 lg:pt-20">
          <div className="relative z-10 self-center">
            <p className="eyebrow mb-6"><span className="eyebrow-dot" /> A clearer way through the things that matter</p>
            <h1 className="max-w-[690px] font-display text-[clamp(3.3rem,7vw,6.9rem)] font-semibold leading-[.92] tracking-[-0.065em] text-[#1F2923]">Find the help that fits your <em className="text-[#B65E43]">next step.</em></h1>
            <p className="mt-8 max-w-[570px] text-lg leading-8 text-[#526057] lg:text-xl">Common Ground brings together practical support, local places, and good ideas for everyday life—so you can begin with less searching and more certainty.</p>
            <div id="find-help" className="mt-10 max-w-[620px] rounded-[4px] border border-[#1F2923]/15 bg-[#FFFDF8] p-2 shadow-[5px_5px_0_#D9CBB7]">
              <label htmlFor="resource-search" className="sr-only">Search for help or resources</label>
              <div className="flex items-center gap-3"><Search className="ml-3 shrink-0 text-[#B65E43]" size={22} /><Input id="resource-search" value={query} onChange={(e) => setQuery(e.target.value)} placeholder="What would be useful right now?" className="h-12 border-0 bg-transparent text-base shadow-none focus-visible:ring-0" /><Button onClick={() => document.getElementById("resources")?.scrollIntoView({ behavior: "smooth" })} className="h-12 shrink-0 rounded-[2px] bg-[#355A45] px-5 font-bold text-[#FFFDF8] hover:bg-[#264735]">Search <ArrowUpRight size={17} /></Button></div>
            </div>
            <p className="mt-4 text-xs font-bold uppercase tracking-[.16em] text-[#7B857D]">Try “food support”, “a new skill”, or “somewhere to belong”</p>
          </div>
          <div className="relative min-h-[380px] lg:min-h-[560px]">
            <div className="absolute -right-10 top-0 h-full w-[94%] overflow-hidden rounded-t-[180px] rounded-br-[12px] rounded-bl-[12px] bg-[#D8E3D7] lg:right-0"><img src="/manus-storage/common-ground-hero_24c35ff5.jpg" alt="Neighbours gathered around a community table" className="h-full w-full object-cover" /></div>
            <div className="absolute bottom-3 left-0 z-10 max-w-[245px] border border-[#1F2923]/20 bg-[#E5A83B] p-5 shadow-[5px_5px_0_#1F2923] lg:bottom-10 lg:left-[-25px]"><p className="font-display text-2xl font-semibold leading-tight">Good information should feel like a hand on your shoulder.</p><span className="mt-3 block text-xs font-bold uppercase tracking-[.15em]">The Common Ground promise</span></div>
            <span className="absolute right-3 top-4 font-display text-7xl text-[#B65E43]/70 lg:right-[-15px]">↗</span>
          </div>
        </section>

        <section className="border-y border-[#1F2923]/10 bg-[#E6EDE4]" aria-labelledby="categories-title">
          <div className="mx-auto max-w-[1320px] px-5 py-16 lg:px-10 lg:py-20"><div className="mb-10 flex items-end justify-between gap-6"><div><p className="eyebrow mb-4">A place to begin</p><h2 id="categories-title" className="font-display text-4xl font-semibold tracking-[-.045em] md:text-5xl">What are you looking for?</h2></div><span className="hidden max-w-[220px] text-right text-sm leading-6 text-[#526057] md:block">No wrong door. Start with the part of life that is on your mind.</span></div>
            <div className="grid gap-3 md:grid-cols-2 lg:grid-cols-4">{categories.map(({ label, detail, icon: Icon, color }, index) => <button key={label} onClick={comingSoon} className={`group relative min-h-[200px] overflow-hidden border border-[#1F2923]/15 p-6 text-left transition-all duration-200 hover:-translate-y-1 hover:shadow-[5px_5px_0_#1F2923] ${color}`}><span className="mb-10 flex items-center justify-between"><Icon size={28} strokeWidth={1.5} /><span className="font-mono text-xs text-[#526057]">0{index + 1}</span></span><span className="block font-display text-2xl font-semibold leading-tight">{label}</span><span className="mt-2 block max-w-[210px] text-sm leading-5 text-[#526057]">{detail}</span><ChevronRight className="absolute bottom-5 right-5 transition-transform duration-200 group-hover:translate-x-1" size={18} /></button>)}</div>
          </div>
        </section>

        <section id="resources" className="mx-auto max-w-[1320px] px-5 py-20 lg:px-10 lg:py-28" aria-labelledby="resources-title">
          <div className="grid gap-10 lg:grid-cols-[.42fr_1fr] lg:gap-24"><div><p className="eyebrow mb-4">The guide</p><h2 id="resources-title" className="font-display text-4xl font-semibold leading-[.98] tracking-[-.05em] md:text-5xl">Useful things, clearly put.</h2><p className="mt-6 max-w-[280px] leading-7 text-[#526057]">Short reads and steady starting points, made for real life—not for perfect circumstances.</p><button onClick={comingSoon} className="mt-8 inline-flex items-center gap-2 border-b-2 border-[#B65E43] pb-1 text-sm font-bold text-[#B65E43]">See everything <ArrowUpRight size={16} /></button></div><div className="space-y-5">{filtered.length ? filtered.map((resource, index) => <article key={resource.title} className="group grid gap-5 border-t border-[#1F2923]/20 pt-5 sm:grid-cols-[180px_1fr] lg:grid-cols-[220px_1fr]" style={{ animationDelay: `${index * 50}ms` }}><img src={resource.image} alt="" className="aspect-[4/3] w-full object-cover grayscale-[.1] transition duration-300 group-hover:grayscale-0" /><div><div className="mb-3 flex items-center gap-3 text-xs font-bold uppercase tracking-[.14em] text-[#B65E43]"><span>{resource.tag}</span><span className="h-1 w-1 rounded-full bg-[#B65E43]" /><span className="flex items-center gap-1 text-[#7B857D]"><Clock3 size={13} /> {resource.time}</span></div><h3 className="font-display text-2xl font-semibold leading-tight tracking-[-.03em] transition-colors group-hover:text-[#B65E43]">{resource.title}</h3><p className="mt-3 max-w-[560px] leading-6 text-[#526057]">{resource.description}</p></div></article>) : <div className="border-t border-[#1F2923]/20 py-10"><p className="font-display text-2xl">Nothing matched that search yet.</p><button onClick={() => setQuery("")} className="mt-3 text-sm font-bold text-[#B65E43] underline">Clear search</button></div>}</div></div>
        </section>

        <section className="bg-[#355A45] text-[#F6F1E8]"><div className="mx-auto flex max-w-[1320px] flex-col gap-8 px-5 py-16 md:flex-row md:items-center md:justify-between lg:px-10 lg:py-20"><div><p className="eyebrow mb-4 text-[#E5A83B]"><span className="eyebrow-dot bg-[#E5A83B]" /> Keep the circle growing</p><h2 className="max-w-[620px] font-display text-4xl font-semibold leading-tight tracking-[-.045em] md:text-5xl">Know a resource that should be here?</h2></div><Button onClick={comingSoon} className="w-fit rounded-[2px] bg-[#E5A83B] px-6 py-6 font-bold text-[#1F2923] hover:bg-[#F3C46D]">Suggest a resource <ArrowUpRight size={17} /></Button></div></section>
      </main>

      <footer className="bg-[#1F2923] text-[#F6F1E8]"><div className="mx-auto flex max-w-[1320px] flex-col gap-8 px-5 py-10 md:flex-row md:items-end md:justify-between lg:px-10"><div><div className="flex items-center gap-3"><span className="grid size-8 place-items-center rounded-full bg-[#E5A83B]"><img src="/manus-storage/common-ground-loop-mark_6d1b3c89.png" alt="" className="size-6" /></span><span className="font-display text-xl font-bold">Common Ground<span className="text-[#E5A83B]">.</span></span></div><p className="mt-3 max-w-[300px] text-sm leading-6 text-[#B6C0B7]">A practical guide to support, places, and possibilities in everyday life.</p></div><div className="text-left text-xs uppercase tracking-[.16em] text-[#B6C0B7] md:text-right"><p>Made for people, by people</p><p className="mt-2">© 2026 Common Ground</p></div></div></footer>
    </div>
  );
}
