# Common Ground — Design Direction

## Three Initial Approaches

### Theme Name: Civic Warmth
Very Brief Intro: A calm, human-centered public-service interface using warm paper tones, confident ink typography, and optimistic civic accents. It should feel trustworthy without feeling bureaucratic.
Probability: 0.07

### Theme Name: Field Notes
Very Brief Intro: An editorial resource guide inspired by annotated maps, community noticeboards, and local newspapers, with visible structure and tactile details. It turns public information into something easy to browse and remember.
Probability: 0.03

### Theme Name: Quiet Signal
Very Brief Intro: A restrained, high-contrast system built around clear wayfinding, generous whitespace, and one vivid signal color. It communicates urgency and usefulness without visual noise.
Probability: 0.09

## Chosen Approach: Field Notes

### Design Movement
Contemporary editorial civic design, borrowing from Swiss information design and independent print publications while keeping the warmth of a neighborhood resource board.

### Core Principles
1. Make the next helpful action obvious within seconds.
2. Pair serious information with humane language and visual warmth.
3. Use asymmetry, editorial rhythm, and layered paper-like surfaces instead of generic centered cards.
4. Make every interaction feel lightweight, reversible, and respectful of attention.

### Color Philosophy
The base is an oat-paper neutral that feels approachable and tactile, balanced by deep ink for reading and a moss green for steadiness. A single marigold signal color highlights actions and moments of optimism. Color should explain hierarchy, not decorate it.

### Layout Paradigm
A left-anchored editorial column is paired with an offset resource rail, creating a page that reads like a well-designed field guide. Sections use staggered alignments, dividers, and occasional full-bleed color bands rather than a repeated centered grid.

### Signature Elements
- A hand-drawn-looking loop mark used as the brand symbol and favicon.
- Fine ink rules and small uppercase metadata labels, like marginal notes in a field guide.
- Marigold “signal tabs” that mark featured actions and time-sensitive information.

### Interaction Philosophy
Users should always understand where they are and what happens next. Search responds immediately, category filters remain visible, and buttons use small physical-feeling press states. Placeholder actions use a clear “coming next” toast rather than pretending to work.

### Animation
Use short 160–240ms ease-out transitions for hover, focus, and filtering. Reveal content with subtle upward movement and opacity only when reduced motion is not requested. Stagger editorial rows by 40ms, never animate layout dimensions, and keep keyboard interactions instant.

### Typography System
Display: Fraunces, 600–700, for humanist headlines and moments of invitation. Body: DM Sans, 400–600, for clarity at small sizes. Metadata: DM Sans, 700, uppercase with generous tracking. Headline line-height stays tight; body copy uses relaxed 1.55–1.7 leading.

### Brand Essence
Common Ground is a practical civic guide for people looking for support, opportunities, or a place to begin; it is different because it turns scattered public resources into a calm, human path forward.
Personality: grounded, generous, resourceful.

### Brand Voice
Headlines are direct, warm, and specific. CTAs sound like invitations to take one manageable step. Microcopy reassures without overpromising.

Example lines:
- “Find the help that fits your next step.”
- “A clearer way through the things that matter.”

### Wordmark & Logo
The mark is a bold, looping line that forms a small open knot: two paths crossing and continuing outward, representing shared ground without using a literal handshake or house icon. The wordmark uses a custom-spaced Fraunces treatment with a slightly oversized “C”.

### Signature Brand Color
Marigold Signal — #E5A83B. It is warm enough to feel human, strong enough to guide attention, and ownable against the oat, ink, moss, and terracotta support palette.
